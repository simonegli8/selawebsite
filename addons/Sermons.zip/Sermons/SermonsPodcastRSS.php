<?php

defined('is_running') or die('Not an entry point...');

require_once('Setup.php');

require_once('rss.php');
die();